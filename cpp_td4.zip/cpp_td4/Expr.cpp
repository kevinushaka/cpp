//=======================================================================
//class Expression
//      Specification and implementation
//-----------------------------------------------------------------------
// Julien DeAntoni (inspired from Jean-Paul Rigault course)
// April 2010
//=======================================================================


#include "Expr.h"


    int Expr::eval()const{
            return 0;
    };

    Expr::~Expr(){

    }